#include <avr/interrupt.h>

#include "GpioPinMacros.h"
#include "SystemClock.h"
#include "Usart.h"

GpioPinObject onboardLed = makeGpioPinObject(GpioPin(B, 7)); //red underline and error by Intellisense can be ignored
Usart usart0 = makeUsartObject(0);


int main()
{
    usart0.init(9600);
    usart0.usartPrintf("Starting program ...\r\n");

    onboardLed.setModeOutput();
    onboardLed.writeDigital(c_Low);

    initTimer0AsSystemClock();
    sei();

    while (1)
    {
        onboardLed.toggle();
        delayMilliseconds(100);
    }
}